﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'el', {
	button: 'Επικόλληση ως απλό κείμενο',
	title: 'Επικόλληση ως απλό κείμενο'
} );
